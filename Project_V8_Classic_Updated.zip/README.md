Run:
 npm install
 npm run seed
 npm start
 Login: omar / 12345
