const express = require('express');
const path = require('path');
const fs = require('fs');
const fileUpload = require('express-fileupload');
const getPort = require('get-port');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(fileUpload());
app.use(express.static(path.join(__dirname, 'public')));

const dbFile = path.join(__dirname, 'data', 'habilitations.sqlite3');
const needSeed = !fs.existsSync(dbFile);
const db = new sqlite3.Database(dbFile);

// init DB
db.serialize(()=>{
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT, created_at TEXT
  );`);
  db.run(`CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY, nom TEXT, prenom TEXT, matricule TEXT UNIQUE, division TEXT, service TEXT, equipe TEXT, created_at TEXT, updated_at TEXT
  );`);
  db.run(`CREATE TABLE IF NOT EXISTS habilitations (
    id INTEGER PRIMARY KEY, employee_id INTEGER, n_titre TEXT, type TEXT, date_val TEXT, date_exp TEXT, pdf_url TEXT, created_at TEXT, updated_at TEXT
  );`);
});

// seed admin + sample data if needed
if(needSeed){
  const hash = bcrypt.hashSync('12345', 10);
  db.run('INSERT OR IGNORE INTO users (username,password_hash,created_at) VALUES (?,?,?)', ['omar', hash, new Date().toISOString()]);
  // load seed json if exists
  try{
    const seed = JSON.parse(fs.readFileSync(path.join(__dirname,'seed_data.json'),'utf8'));
    const empStmt = db.prepare('INSERT INTO employees (nom,prenom,matricule,division,service,equipe,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)');
    const habStmt = db.prepare('INSERT INTO habilitations (employee_id,n_titre,type,date_val,date_exp,pdf_url,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)');
    for(const e of seed){
      const info = empStmt.run(e.nom,e.prenom,e.matricule,e.division,e.service,e.equipe,new Date().toISOString(),new Date().toISOString());
      const empId = info.lastID;
      if(e.habilitations){
        for(const h of e.habilitations){
          habStmt.run(empId,h.n_titre,h.type,h.date_val,h.date_exp,h.pdf_url || null,new Date().toISOString(),new Date().toISOString());
        }
      }
    }
    empStmt.finalize(); habStmt.finalize();
    console.log('Seeded DB from seed_data.json');
  }catch(err){ console.log('No seed_data.json found or error', err.message); }
}

// auth login
app.post('/auth/login', (req,res)=>{
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ?', [username], (err,row)=>{
    if(err) return res.json({success:false, message:err.message});
    if(!row) return res.json({success:false, message:'Utilisateur introuvable'});
    const ok = bcrypt.compareSync(password, row.password_hash);
    if(!ok) return res.json({success:false, message:'Mot de passe incorrect'});
    res.json({success:true, username:row.username});
  });
});

// GET employees with habilitations
app.get('/api/employees', (req,res)=>{
  db.all('SELECT * FROM employees', [], (err,rows)=>{
    if(err) return res.status(500).json({error:err.message});
    const empMap = {};
    rows.forEach(r=> empMap[r.id]=Object.assign({}, r, {habilitations:[]}) );
    db.all('SELECT * FROM habilitations', [], (err2,hs)=>{
      if(err2) return res.status(500).json({error:err2.message});
      hs.forEach(h=>{ if(empMap[h.employee_id]) empMap[h.employee_id].habilitations.push(h); });
      res.json(Object.values(empMap));
    });
  });
});

// GET single employee
app.get('/api/employees/:id', (req,res)=>{
  const id = req.params.id;
  db.get('SELECT * FROM employees WHERE id=?', [id], (err,row)=>{
    if(err) return res.status(500).json({error:err.message});
    if(!row) return res.status(404).json({error:'Not found'});
    db.all('SELECT * FROM habilitations WHERE employee_id=?', [id], (err2,hs)=>{
      if(err2) return res.status(500).json({error:err2.message});
      row.habilitations = hs;
      res.json(row);
    });
  });
});

// Add employee (and optional habilitations)
app.post('/api/employees', (req,res)=>{
  const e = req.body;
  const now = new Date().toISOString();
  db.run('INSERT INTO employees (nom,prenom,matricule,division,service,equipe,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)',
    [e.nom,e.prenom,e.matricule,e.division,e.service,e.equipe,now,now], function(err){
      if(err) return res.status(500).json({error:err.message});
      const empId = this.lastID;
      if(e.habilitations && Array.isArray(e.habilitations)){
        const stmt = db.prepare('INSERT INTO habilitations (employee_id,n_titre,type,date_val,date_exp,pdf_url,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)');
        for(const h of e.habilitations){
          stmt.run(empId, h.n_titre || '', h.type || '', h.date_val || '', h.date_exp || '', h.pdf_url || null, now, now);
        }
        stmt.finalize();
      }
      res.json({success:true, id:empId});
    });
});

// Update employee
app.put('/api/employees/:id', (req,res)=>{
  const id=req.params.id; const e=req.body; const now=new Date().toISOString();
  db.run('UPDATE employees SET nom=?,prenom=?,matricule=?,division=?,service=?,equipe=?,updated_at=? WHERE id=?',
    [e.nom,e.prenom,e.matricule,e.division,e.service,e.equipe,now,id], function(err){
      if(err) return res.status(500).json({error:err.message});
      res.json({success:true});
    });
});

// Delete employee and related habilitations + PDFs
app.delete('/api/employees/:id', (req,res)=>{
  const id = req.params.id;
  // remove PDFs
  db.all('SELECT pdf_url FROM habilitations WHERE employee_id=?', [id], (err,rows)=>{
    if(rows) rows.forEach(r=>{
      if(r && r.pdf_url){
        const p = path.join(__dirname, 'public', r.pdf_url.replace(/^\//,''));
        if(fs.existsSync(p)) try{ fs.unlinkSync(p); }catch(e){}
      }
    });
    db.run('DELETE FROM habilitations WHERE employee_id=?', [id], (err2)=>{
      if(err2) console.log(err2.message);
      db.run('DELETE FROM employees WHERE id=?', [id], function(err3){
        if(err3) return res.status(500).json({error:err3.message});
        res.json({success:true});
      });
    });
  });
});

// Add habilitation to employee
app.post('/api/employees/:id/habilitations', (req,res)=>{
  const id=req.params.id; const h=req.body; const now=new Date().toISOString();
  db.run('INSERT INTO habilitations (employee_id,n_titre,type,date_val,date_exp,pdf_url,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)',
    [id,h.n_titre||'',h.type||'',h.date_val||'',h.date_exp||'',h.pdf_url||null,now,now], function(err){
      if(err) return res.status(500).json({error:err.message});
      res.json({success:true, id:this.lastID});
    });
});

// Update habilitation
app.put('/api/habilitations/:id', (req,res)=>{
  const id=req.params.id; const h=req.body; const now=new Date().toISOString();
  db.run('UPDATE habilitations SET n_titre=?,type=?,date_val=?,date_exp=?,pdf_url=?,updated_at=? WHERE id=?',
    [h.n_titre||'',h.type||'',h.date_val||'',h.date_exp||'',h.pdf_url||null,now,id], function(err){
      if(err) return res.status(500).json({error:err.message});
      res.json({success:true});
    });
});

// Upload PDF
app.post('/api/upload', (req,res)=>{
  if(!req.files || !req.files.pdf) return res.status(400).json({error:'No file'});
  const pdf = req.files.pdf;
  if(pdf.mimetype !== 'application/pdf') return res.status(400).json({error:'Only PDFs allowed'});
  if(pdf.size > 10 * 1024 * 1024) return res.status(400).json({error:'Max 10MB'});
  const safe = Date.now() + '-' + pdf.name.replace(/[^a-z0-9.\\-_/]/gi,'_');
  const dest = path.join(__dirname, 'public', 'uploads', safe);
  pdf.mv(dest, (err)=>{ if(err) return res.status(500).json({error:err.message}); res.json({url:'/uploads/'+safe}); });
});

// Delete PDF file and unlink from habilitation
app.post('/api/habilitations/:id/delete-pdf', (req,res)=>{
  const id = req.params.id;
  db.get('SELECT pdf_url FROM habilitations WHERE id=?', [id], (err,row)=>{
    if(err) return res.status(500).json({error:err.message});
    if(row && row.pdf_url){
      const p = path.join(__dirname, 'public', row.pdf_url.replace(/^\//,''));
      if(fs.existsSync(p)) try{ fs.unlinkSync(p); }catch(e){}
      db.run('UPDATE habilitations SET pdf_url=NULL WHERE id=?', [id], function(err2){
        if(err2) return res.status(500).json({error:err2.message});
        res.json({success:true});
      });
    } else res.json({success:false, message:'No pdf'});
  });
});

// Backup DB
app.get('/api/backup', (req,res)=> res.download(dbFile));

// start server auto-port
(async ()=>{
  const port = await getPort({ port: [3000,3001,3002,3003,3004,3005] });
  app.listen(port, ()=> console.log(`Server running at http://localhost:${port}`));
})();
