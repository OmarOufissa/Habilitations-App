window.showModalGlobal = function(opts){
  const modalBackdrop = document.getElementById('modalBackdrop');
  const title = document.getElementById('modalTitle');
  const body = document.getElementById('modalBody');
  const actions = document.getElementById('modalActions');
  title.innerText = opts.title || 'Confirmer';
  body.innerHTML = opts.body || '';
  actions.innerHTML = '';
  if(!opts.hideCancel){
    const b = document.createElement('button'); b.innerText = opts.cancelText || 'Annuler'; b.className='secondary'; b.onclick = ()=> modalBackdrop.classList.remove('show'); actions.appendChild(b);
  }
  const confirm = document.createElement('button'); confirm.innerText = opts.confirmText || 'Confirmer'; if(opts.confirmClass==='danger') confirm.className='danger';
  confirm.onclick = async ()=>{ modalBackdrop.classList.remove('show'); if(typeof opts.confirmAction === 'function') await opts.confirmAction(); };
  actions.appendChild(confirm);
  modalBackdrop.classList.add('show');
};
window.showToastGlobal = function(msg, ms=2200){ const t=document.getElementById('toast'); t.innerText=msg; t.classList.add('show'); setTimeout(()=> t.classList.remove('show'), ms); };